import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class SignIn extends JFrame{//�α���ȭ��
	Image img = null;
	private Font f1;
	private Font f2;
	private Font f3;
	
	public SignIn()
	{        
        Container contentPane=getContentPane();  //��� �̹���
		JPanel p=new JPanel() {

			public void paintComponent(Graphics g) {

				Dimension d=getSize();
				ImageIcon image = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\111.jpg");
				g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
				setOpaque(false);
				super.paintComponent(g);
			}

		};

		contentPane.add(p);
		p.setLayout(null);


	
		f1 = new Font("210 ����ü�� B", Font.BOLD, 50);
		f2 = new Font("1HoonTop Bold italic", Font.BOLD, 50);
		f3 = new Font("Masque", Font.BOLD, 55);
		
		JLabel A1= new JLabel("SOFTWARE");
		A1.setForeground(Color.BLACK);
		A1.setFont(f3);
		add(A1);
		JLabel A2= new JLabel("INFORMATION");
		A2.setForeground(Color.BLACK);
		A2.setFont(f3);
		add(A2);
		
		JLabel b2= new JLabel("�й�");
		b2.setForeground(Color.white);
		b2.setFont(f1);
		add(b2);
		JLabel b3= new JLabel("PW");
		b3.setForeground(Color.white);
		b3.setFont(f2);		
		add(b3);
		TextField b4 = new TextField();
		b4.setFont(new Font("1HoonTop Bold italic", Font.PLAIN, 32));
		add(b4);
		TextField b5 = new TextField();
		b5.setFont(new Font("1HoonTop Bold italic", Font.PLAIN, 32));
		add(b5);
		b5.setEchoChar('*');//��ȣȭ
		
		JButton b6 = new JButton("SignIn");
		b6.setFont(new Font("1HoonTop Bold italic", Font.PLAIN, 35));
		b6.setBackground (new Color(62, 60,61));	
		b6.setForeground(Color.white);
		add(b6);
		JButton b7 = new JButton("SignUp");
		b7.setFont(new Font("1HoonTop Bold italic", Font.PLAIN, 35));
		b7.setBackground (new Color(62, 60,61));	
		b7.setForeground(Color.white);
		add(b7);
		
		
		A1.setBounds(110, 220, 500, 60);
		A2.setBounds(65, 280, 500, 60);
		b2.setBounds(690, 305, 120, 60);
		b3.setBounds(690, 390, 120, 50);
		b4.setBounds(820, 305, 270, 45);
		b5.setBounds(820, 390, 270, 45);
		b6.setBounds(690, 530, 150, 50);
		b7.setBounds(925, 530, 150, 50);
		add(p);
		setSize(1200, 867);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //x������ â�����°�
		setTitle("SOFTWARE INFOORMATION ");
		setVisible(true); //���̰�
		setLocationRelativeTo(null); //â �����
		b7.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {//ȸ������â���� �̵�
				// TODO Auto-generated method stub
				new SignUp();
				
			}
		});;
		b6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e2) {//�α��� �Ҷ� 
				SignUpDTO inform = new SignInDAO().isSignIn(b4.getText(), b5.getText());				
					if(inform != null)
					{
						JOptionPane.showMessageDialog(null, "�α����� �Ǿ����ϴ�!!");						
						dispose();
						new Menu(inform.getYear());
						
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "�α����� �����Ͽ����ϴ�.");
					}

			}
		});
	}
}

