
public class SignUpDTO {
   private String SchoolID;
   private String PW;
   private String name;
   private String year;
   
   public SignUpDTO() {
      super();
      this.SchoolID = "";
      this.PW = "";
      this.name = "";
      this.year="";
   }
   
   public SignUpDTO(String schoolID, String pW, String name) {
      super();
      this.SchoolID = schoolID;
      this.PW = pW;
      this.name = name;
      this.year=schoolID.substring(2,4);
   }
   public String getSchoolID() {
      return SchoolID;
   }
   public void setSchoolID(String schoolID) {
      SchoolID = schoolID;
   }
   public String getPW() {
      return PW;
   }
   public void setPW(String pW) {
      PW = pW;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getYear() {
      return year;
   }
   public void setYear(String year) {
      this.year=year;
   }

   
}