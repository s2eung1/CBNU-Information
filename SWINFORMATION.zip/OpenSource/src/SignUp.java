import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import javax.swing.*;
import java.awt.*;

public class SignUp extends JFrame {// ȸ������ȭ��
	Image img = null;
	private Font f3;
	private Font f2;
	
	public SignUp() {
		 Container contentPane=getContentPane();  //��� �̹���
			JPanel p = new JPanel() {

				public void paintComponent(Graphics g) {

					Dimension d=getSize();
					ImageIcon image = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\222.jpg");
					g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
					setOpaque(false);
					super.paintComponent(g);
				}

			};

			contentPane.add(p);
			p.setLayout(null);
			
			/*f2 = new Font("Masque", Font.BOLD, 37);
			JLabel A1= new JLabel("SOFTWARE");
			A1.setForeground(Color.white);
			A1.setFont(f2);
			A1.setBounds(335, 690, 500, 60);		
			add(A1);
			JLabel A2= new JLabel("INFORMATION");
			A2.setForeground(Color.white);
			A2.setFont(f2);
			A2.setBounds(315, 730, 500, 60);
			add(A2);*/
		
		f3 = new Font("210 ����ü�� B", Font.BOLD, 35);
		JLabel l1 = new JLabel("�̸�");
		l1.setFont(f3);
		l1.setForeground(Color.white);
		l1.setBounds(150, 230, 100, 40);
		
		JLabel l2 = new JLabel("�й�");
		l2.setFont(f3);
		l2.setForeground(Color.white);
		l2.setBounds(150, 300, 100, 40);
		
		JLabel l3 = new JLabel("PW");
		l3.setFont(f3);
		l3.setForeground(Color.white);
		l3.setBounds(150, 370, 100, 40);
		
		JLabel l4 = new JLabel("PW Ȯ��");
		l4.setFont(f3);
		l4.setForeground(Color.white);
		l4.setBounds(120, 440, 160, 40);
		
		JLabel l5 = new JLabel("< SIGN UP >");
		l5.setFont(new Font("210 ����ü�� B", Font.BOLD, 55));
		l5.setForeground(Color.white);
		l5.setBounds(230, 80, 380, 80);

		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		

		TextField t1 = new TextField();
		TextField t2 = new TextField();
		TextField t3 = new TextField();
		TextField t4 = new TextField();
		t1.setBounds(300, 230, 270, 42);
		t1.setFont(new Font("210 ����ü�� B", Font.PLAIN, 32));
		t2.setBounds(300, 300, 270, 42);
		t2.setFont(new Font("210 ����ü�� B", Font.PLAIN, 32));		
		t3.setBounds(300, 370, 270, 42);
		t3.setFont(new Font("210 ����ü�� B", Font.PLAIN, 32));
		t4.setBounds(300, 440, 270, 42);
		t4.setFont(new Font("210 ����ü�� B", Font.PLAIN, 32));
		add(t1);
		add(t2);
		add(t3);
		add(t4);

		t3.setEchoChar('*');
		t4.setEchoChar('*');
		
		JButton j1 = new JButton("save");
		j1.setFont(new Font("1HoonTop Bold italic", Font.BOLD, 36));
		j1.setBackground (new Color(62, 60, 61));	
		j1.setForeground(new Color(254, 210, 89));
		j1.setBounds(170, 560, 140, 45);
		
		JButton j2 = new JButton("cancle");
		j2.setFont(new Font("1HoonTop Bold italic", Font.BOLD, 36));
		j2.setBackground (new Color(62, 60, 61));	
		j2.setForeground(new Color(254, 210, 89));
		j2.setBounds(485, 560, 140, 45);
		
		JButton j3 = new JButton("�ߺ�Ȯ��");
		j3.setFont(new Font("210 ����ü�� B", Font.BOLD, 20));
		//j3.setBackground (new Color(62, 60, 61));	
		j3.setBackground (new Color(62, 60, 61));	
		j3.setForeground(Color.white);
		j3.setBounds(600, 300, 117, 42);
		add(j1);
		add(j2);
		add(j3);
		
		
		
		add(p);
		setSize(800, 900);
		setTitle("ȸ������");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null);//â �����
		j1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent T) {// ȸ������ ������ ����
					if(t3.getText().equals(t4.getText())) {
						new SignUpDAO().SignUpMember(new SignUpDTO(t2.getText(),t3.getText(),t1.getText()));
						JOptionPane.showMessageDialog(null, "ȸ�������� �Ϸ�Ǿ����ϴ�.");
						dispose();
						
					}
					else {
						JOptionPane.showMessageDialog(null, "��й�ȣ Ȯ���� ���ּ���.");
					}
			}
		});
		j2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent T) {// ���
					dispose();
			}
		});
		j3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent T) {// �ߺ�Ȯ��
					boolean dup = new SignUpDAO().duplicationCheck(t2.getText());
					if(dup) {
						JOptionPane.showMessageDialog(null, "�й��� �ߺ� �Ǿ����ϴ�.");
					}
					else {
						JOptionPane.showMessageDialog(null, "��� ������ ���̵��Դϴ�.");
						t2.setEditable(false);
					}
			}
		});
	}
}
