import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class Graduation extends JFrame {

   ImageIcon icon; //�̹��� ����
   JScrollPane jsp = new JScrollPane(); //��ũ�� ����
   SignUpDTO sDTO=new SignUpDTO(); //�л� ���� �ޱ� ����
      
   public Graduation(String year) {
      
      this.setTitle("Graduation Condition");

      if (year.equals("15")) { //15�й��� ��
         icon = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\15�й�.png"); //�̹��� ���ϰ��

         JScrollPane jsp = new JScrollPane(new JLabel(icon)); //��ũ�� �� �̹��� �߰�
         getContentPane().add(jsp);
         setSize(1200, 867);
         setVisible(true);
         setLocationRelativeTo(null);
      } else if (year.equals("16")) {
         icon = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\16�й�.png");

         JScrollPane jsp = new JScrollPane(new JLabel(icon));
         getContentPane().add(jsp);
         setSize(1200, 867);
         setVisible(true);
         setLocationRelativeTo(null);
      } else if (year.equals("17")) {
         icon = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\17�й�.png");

         JScrollPane jsp = new JScrollPane(new JLabel(icon));
         getContentPane().add(jsp);
         setSize(1200, 867);
         setVisible(true);
         setLocationRelativeTo(null);
      } else if (year.equals("18")) {
         icon = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\18�й�.png");

         JScrollPane jsp = new JScrollPane(new JLabel(icon));
         getContentPane().add(jsp);
         setSize(1200, 867);
         setVisible(true);
         setLocationRelativeTo(null);
      } else if (year.equals("19")) {
         icon = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\19�й�.png");

         JScrollPane jsp = new JScrollPane(new JLabel(icon));
         getContentPane().add(jsp);
         setSize(1200, 867);
         setVisible(true);
         setLocationRelativeTo(null);
         }
      }
     
}