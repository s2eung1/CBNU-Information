import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu extends JFrame {
	Image img = null;
	private Font f3;

   /**
    * Create the frame.
    */
   public Menu(String year) {
	   this.setTitle("SOFTWARE INFORMATION");	      
	      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   
	   Container contentPane=getContentPane();  //��� �̹���
		JPanel p = new JPanel() {

			public void paintComponent(Graphics g) {

				Dimension d=getSize();
				ImageIcon image = new ImageIcon("C:\\Users\\jijki\\OneDrive\\���� ȭ��\\11.jpg");
				g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
				setOpaque(false);
				super.paintComponent(g);
			}

		};

		contentPane.add(p);
		p.setLayout(null);
		
	   
      /*this.setTitle("SOFTWARE INFORMATION");
      
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(205, 100, 1200, 867); 
      contentPane = new JPanel();
      contentPane.setBackground(new Color(62, 60, 61)); //ȸ�����
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      setContentPane(contentPane);
      contentPane.setLayout(null);*/
      
    
      
      /*JPanel panel_1 = new JPanel(); //���� �����  (����)
      panel_1.setBounds(0, 0, 600, 867);
      contentPane.add(panel_1);
      panel_1.setBackground(new Color(254, 210, 89));
      panel_1.setLayout(null);*/
      
      /*Label label = new Label("SOFTWARE");(����)
      label.setFont(new Font("Masque", Font.BOLD, 55));
      label.setAlignment(Label.CENTER);
      label.setBounds(67, 110, 440, 45);
      //panel_1.add(label);
      add(label);
      
      Label label_1 = new Label("INFORMATION");(����)
      label_1.setFont(new Font("Masque", Font.BOLD, 55));
      label_1.setAlignment(Label.CENTER);
      label_1.setBounds(63, 160, 440, 45);
      //panel_1.add(label_1);
      add(label_1);*/
      
		f3 = new Font("Masque", Font.BOLD, 55);
		JLabel A1= new JLabel("SOFTWARE");
		A1.setForeground(Color.BLACK);
		A1.setFont(f3);
		A1.setBounds(110, 220, 500, 60);		
		add(A1);
		JLabel A2= new JLabel("INFORMATION");
		A2.setForeground(Color.BLACK);
		A2.setFont(f3);
		A2.setBounds(65, 280, 500, 60);
		add(A2);
      
      
      /*JLabel lblNewLabel = new JLabel("New label"); (����)
      lblNewLabel.setIcon(new ImageIcon(Menu.class.getResource("./images/cbnulogo.png")));
      lblNewLabel.setBounds(200, 320, 181, 210);
      //panel_1.add(lblNewLabel);
      add(lblNewLabel);*/
      
      /*Button button = new Button("\uAD50\uC218 \uC815\uBCF4");
      button.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent arg0) {
            
         }
      });
      button.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent arg0) {
            new Professor_List();
         }
      });
      button.setBackground(new Color(254, 210, 89));
      button.setFont(new Font("210 ����ü�� B", Font.BOLD, 30));
      button.setBounds(700, 180, 380, 120);
      //contentPane.add(button);
      add(button);*/
      
      JButton button = new JButton("���� ����");
      button.setFont(new Font("210 ����ü�� B", Font.BOLD, 43));
      button.setBackground (new Color(254, 210, 89));	
      button.setForeground(Color.black);
      button.setBounds(700, 180, 380, 120);
      button.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent arg0) {
             
          }
       });
       button.addMouseListener(new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent arg0) {
             new Professor_List();
          }
       });
		add(button);
		
		 
	      JButton button_1 = new JButton("���� ����");
	      button_1.setFont(new Font("210 ����ü�� B", Font.BOLD, 43));
	      button_1.setBackground (new Color(254, 210, 89));	
	      button_1.setForeground(Color.black);
	      button_1.setBounds(700, 350, 380, 120);
	      button_1.addActionListener(new ActionListener() {
	          public void actionPerformed(ActionEvent arg0) {
	             
	          }
	       });
	      button_1.addMouseListener(new MouseAdapter() {
	          @Override
	          public void mouseClicked(MouseEvent arg0) {
	             new MemoCalendar();
	          }
	       });
			add(button_1);
      
		     JButton button_2 = new JButton("���� ���");
		     button_2.setFont(new Font("210 ����ü�� B", Font.BOLD, 43));
		     button_2.setBackground (new Color(254, 210, 89));	
		     button_2.setForeground(Color.black);
		     button_2.setBounds(700, 520, 380, 120);
		      button_2.addActionListener(new ActionListener() {
		          public void actionPerformed(ActionEvent arg0) {
		             
		          }
		       });
		      button_2.addMouseListener(new MouseAdapter() {
		          @Override
		          public void mouseClicked(MouseEvent arg0) {
		             new Graduation(year);
		          }
		       });
				add(button_2);
	      
  
      add(p);
      setSize(1200, 867);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //x������ â�����°�
      setTitle("SOFTWARE INFOORMATION ");
      setVisible(true); //���̰�
      setLocationRelativeTo(null); //â �����
   }
}