import java.sql.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//try {
		//Class.forName("com.mysql.jdbc.Driver");
		//Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/swinfo","root","1234");
		//System.out.println("DB ���� �Ϸ�");
	//} catch (ClassNotFoundException e) {
		//System.out.println("JDBC ����̹� �ε� ����");
	//} catch (SQLException e) {
		//System.out.println("DB ���� ����");
//	}
		new SignIn();
		
	}

}
