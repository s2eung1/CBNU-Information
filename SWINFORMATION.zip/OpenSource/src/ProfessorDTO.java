
public class ProfessorDTO {
	private String name;
	private String room;
	private String room_tel;
	private String email;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getRoom_tel() {
		return room_tel;
	}
	public void setRoom_tel(String room_tel) {
		this.room_tel = room_tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String toString() {
		return "ProfessorDTO [name="+name+", room="+room+", room_tel="+room_tel+", email="+email+"]";
	}
}
