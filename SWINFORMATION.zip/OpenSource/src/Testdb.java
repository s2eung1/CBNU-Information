import java.sql.*;

public class Testdb {
	public Connection con;
	public Statement stmt;
	
	public Testdb(){
		
		con=null;
		stmt=null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/swinformation?characterEncoding=UTF-8&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root",
						"1209");  
			stmt = con.createStatement();
			
		
		} catch (ClassNotFoundException e) {
			System.out.println(e+"JDBC ����̹� �ε� ����");			
		} catch (SQLException e) {
			System.out.println(e+"DB ���� ����");		
		}
	}

	
}