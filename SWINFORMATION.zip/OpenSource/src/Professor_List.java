import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Professor_List extends JFrame implements MouseListener, ActionListener{
	Vector v;
	Vector cols;
	DefaultTableModel model;
	JTable jTable;
	JScrollPane pane;
	JPanel pbtn;
	JButton btnInsert;
	
	public Professor_List() {
		super("���� ����");
		ProfessorDAO dao = new ProfessorDAO();
		v=dao.getProfessorList();
		System.out.println("v="+v);
		cols=getColumn();
		
		model=new DefaultTableModel(v,cols);
		
		jTable=new JTable(model);
		pane=new JScrollPane(jTable);
		add(pane);
		
		jTable.addMouseListener(this); //������ ���
		//btnInsert.addActionListener(this);
		
		setSize(900,567);
		setVisible(true);
		setLocationRelativeTo(null); //â �����
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}//end ������
	
	//table�� �÷�
	public Vector getColumn() {
		Vector col=new Vector();
		col.add("�̸�");
		col.add("������");
		col.add("������ ��ȭ��ȣ");
		col.add("�̸���");
		
		return col;
	}//getColumn
	
	public void jTableRefresh() {
		ProfessorDAO dao=new ProfessorDAO();
		DefaultTableModel model=new DefaultTableModel(dao.getProfessorList(),getColumn());
		jTable.setFont(new Font("210 ����ü�� B", Font.BOLD, 43));
		jTable.setModel(model);
	}
	
	public static void main(String[] args) {
		new Professor_List();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		//��ư�� Ŭ���ϸ�
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
